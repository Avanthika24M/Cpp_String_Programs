#include <algorithm>
#include <cctype>
#include <iostream>
#include <string>

// Reverse words 2, 4, 6, ... while preserving the original whitespace.
int main() {
    std::string text;
    std::getline(std::cin, text);
    std::size_t position = 0;
    unsigned int wordNumber = 0;

    while (position < text.size()) {
        if (std::isspace(static_cast<unsigned char>(text[position]))) {
            ++position;
            continue;
        }

        std::size_t start = position;
        while (position < text.size() &&
               !std::isspace(static_cast<unsigned char>(text[position]))) {
            ++position;
        }

        ++wordNumber;
        if (wordNumber % 2 == 0) {
            // Reverse this word in place using two positions.
            std::size_t left = start;
            std::size_t right = position - 1;
            while (left < right) {
                std::swap(text[left], text[right]);
                ++left;
                --right;
            }
        }
    }

    std::cout << text << '\n';
    return 0;
}
