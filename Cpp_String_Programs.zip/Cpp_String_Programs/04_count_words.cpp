#include <iostream>
#include <sstream>
#include <string>

// Count whitespace-separated words, ignoring extra spaces and tabs.
int main() {
    std::string text;
    std::getline(std::cin, text);
    std::istringstream input(text);
    std::string word;
    std::size_t count = 0;

    while (input >> word) {
        ++count;
    }

    std::cout << count << '\n';
    return 0;
}
