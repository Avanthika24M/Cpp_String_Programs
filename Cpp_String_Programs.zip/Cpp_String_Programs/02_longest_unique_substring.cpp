#include <algorithm>
#include <array>
#include <iostream>
#include <string>

// Sliding window: move the start past the previous repeated character.
int main() {
    std::string text;
    std::getline(std::cin, text);
    std::array<std::size_t, 256> nextStart{};
    std::size_t start = 0;
    std::size_t longest = 0;

    for (std::size_t end = 0; end < text.size(); ++end) {
        unsigned char character = static_cast<unsigned char>(text[end]);
        start = std::max(start, nextStart[character]);
        longest = std::max(longest, end - start + 1);
        nextStart[character] = end + 1;
    }

    std::cout << longest << '\n';
    return 0;
}
