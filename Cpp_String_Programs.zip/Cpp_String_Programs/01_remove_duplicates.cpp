#include <array>
#include <iostream>
#include <string>

// Keep only the first occurrence of each character (case-sensitive).
int main() {
    std::string text;
    std::getline(std::cin, text);
    std::array<bool, 256> seen{};
    std::string result;

    for (unsigned char character : text) {
        if (!seen[character]) {
            result += static_cast<char>(character);
            seen[character] = true;
        }
    }

    std::cout << result << '\n';
    return 0;
}
