# Four C++ String Programs

Each .cpp file is an independent program with its own main(). Compile them separately.
Requires a C++11 or newer compiler. Input is one full line; output contains only the answer.
Do not type surrounding quotation marks from the examples.

| File | Task | Sample input | Sample output |
| --- | --- | --- | --- |
| 01_remove_duplicates.cpp | Keep the first occurrence of every character | programming | progamin |
| 02_longest_unique_substring.cpp | Longest substring without repeated characters: length | abcabcbb | 3 |
| 03_reverse_alternate_words.cpp | Reverse the second, fourth, etc. words | one two three four five | one owt three ruof five |
| 04_count_words.cpp | Count words, ignoring extra whitespace | Welcome to C++ | 3 |

The fourth task is inferred from the screenshot's input/output because its title is not visible.
Programs process ordinary single-byte text, including ASCII; they do not decode Unicode characters.

## Compile and run on a Linux server

After uploading and extracting the ZIP:

```bash
cd Cpp_String_Programs
mkdir -p build
g++ -std=c++11 -Wall -Wextra -pedantic 01_remove_duplicates.cpp -o build/remove_duplicates
g++ -std=c++11 -Wall -Wextra -pedantic 02_longest_unique_substring.cpp -o build/longest_unique_substring
g++ -std=c++11 -Wall -Wextra -pedantic 03_reverse_alternate_words.cpp -o build/reverse_alternate_words
g++ -std=c++11 -Wall -Wextra -pedantic 04_count_words.cpp -o build/count_words
```

Run the program you want and enter its input:

```bash
./build/remove_duplicates
./build/longest_unique_substring
./build/reverse_alternate_words
./build/count_words
```

## Put the folder in Git

```bash
git init
git add .
git commit -m "Add four C++ string programs"
git branch -M main
```

To push, create an empty remote repository, replace YOUR_REPOSITORY_URL with its URL, then run:

```bash
git remote add origin YOUR_REPOSITORY_URL
git push -u origin main
```

On your server, you can then use `git clone YOUR_REPOSITORY_URL`.
